
using System.Collections.Generic;
using UnityEngine;

namespace PlatformerMVS
{
    public class CannonView : MonoBehaviour
    {
        public Transform _muzzleT;
        public Transform _emitterT;
        public List<BulletView> _bullets;
    }
}